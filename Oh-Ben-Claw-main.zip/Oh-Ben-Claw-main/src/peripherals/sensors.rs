//! Sensor tools for ESP32-S3 — camera capture, audio sampling, and generic sensor read.
//!
//! These tools extend the serial JSON protocol with sensor-specific commands:
//! - `camera_capture` — capture a JPEG image from an attached camera module
//! - `audio_sample`   — read an audio RMS level (or raw samples) from an I2S microphone
//! - `sensor_read`    — read a named I2C/SPI sensor field (temperature, humidity, etc.)
//!
//! Requires the `obc-esp32-s3` firmware flashed to the board.
//!
//! # Protocol
//!
//! The host sends a newline-delimited JSON command:
//! ```json
//! {"id":"1","cmd":"camera_capture","args":{"quality":5,"format":"jpeg"}}
//! ```
//!
//! The board responds with a newline-delimited JSON result:
//! ```json
//! {"id":"1","ok":true,"result":"<base64-encoded JPEG>"}
//! ```

use crate::spine::{SpineClient, ToolCallResult};
use crate::tools::traits::{Tool, ToolResult};
use async_trait::async_trait;
use serde_json::{json, Value};
use std::sync::Arc;

/// Convert a spine `ToolCallResult` into a `ToolResult`.
fn tool_result_from_spine(result: ToolCallResult) -> ToolResult {
    if result.ok {
        ToolResult::ok(result.output.unwrap_or_default())
    } else {
        ToolResult::err(result.error.unwrap_or_else(|| "Unknown error".to_string()))
    }
}

/// JPEG quality bounds — must match firmware constants.
pub(crate) const CAMERA_QUALITY_MIN: u64 = 1;
pub(crate) const CAMERA_QUALITY_MAX: u64 = 10;
pub(crate) const CAMERA_QUALITY_DEFAULT: u64 = 5;

/// Audio sample duration bounds (ms) — must match firmware constants.
pub(crate) const AUDIO_DURATION_MIN_MS: u64 = 10;
pub(crate) const AUDIO_DURATION_MAX_MS: u64 = 1000;
pub(crate) const AUDIO_DURATION_DEFAULT_MS: u64 = 100;

// ── Camera Capture Tool ───────────────────────────────────────────────────────

/// Tool: capture a JPEG image from the camera module on an ESP32-S3 board.
pub struct CameraCaptureTool {
    node_id: String,
    spine_client: Option<Arc<SpineClient>>,
}

impl CameraCaptureTool {
    pub fn new(node_id: impl Into<String>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: None,
        }
    }

    pub fn with_spine(node_id: impl Into<String>, spine_client: Arc<SpineClient>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: Some(spine_client),
        }
    }
}

#[async_trait]
impl Tool for CameraCaptureTool {
    fn name(&self) -> &str {
        "camera_capture"
    }

    fn description(&self) -> &str {
        "Capture a JPEG image from the camera module attached to the ESP32-S3 board. \
         Returns a base64-encoded JPEG image. Use this to see what the camera sees."
    }

    fn parameters_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "quality": {
                    "type": "integer",
                    "description": "JPEG quality (1=lowest, 10=highest). Default: 5.",
                    "minimum": CAMERA_QUALITY_MIN,
                    "maximum": CAMERA_QUALITY_MAX,
                    "default": CAMERA_QUALITY_DEFAULT
                },
                "format": {
                    "type": "string",
                    "description": "Image format. Currently only 'jpeg' is supported.",
                    "enum": ["jpeg"],
                    "default": "jpeg"
                }
            }
        })
    }

    async fn execute(&self, args: Value) -> anyhow::Result<ToolResult> {
        let quality = args
            .get("quality")
            .and_then(|v| v.as_u64())
            .unwrap_or(CAMERA_QUALITY_DEFAULT)
            .clamp(CAMERA_QUALITY_MIN, CAMERA_QUALITY_MAX);
        let format = args
            .get("format")
            .and_then(|v| v.as_str())
            .unwrap_or("jpeg")
            .to_string();

        tracing::debug!(
            node_id = %self.node_id,
            quality = quality,
            format = %format,
            "Capturing camera image"
        );

        // Send command via MQTT spine if available, otherwise return stub.
        if let Some(ref spine) = self.spine_client {
            let args = json!({
                "quality": quality,
                "format": format,
            });
            let result = spine
                .invoke_tool(&self.node_id, "camera_capture", args)
                .await?;
            Ok(tool_result_from_spine(result))
        } else {
            Ok(ToolResult {
                success: true,
                output: format!(
                    "Camera capture requested from node '{}' (quality={}, format={}). \
                     No spine client configured — running in stub mode.",
                    self.node_id, quality, format
                ),
                error: None,
            })
        }
    }
}

// ── Audio Sample Tool ─────────────────────────────────────────────────────────

/// Tool: sample audio from the I2S microphone on an ESP32-S3 board.
pub struct AudioSampleTool {
    node_id: String,
    spine_client: Option<Arc<SpineClient>>,
}

impl AudioSampleTool {
    pub fn new(node_id: impl Into<String>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: None,
        }
    }

    pub fn with_spine(node_id: impl Into<String>, spine_client: Arc<SpineClient>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: Some(spine_client),
        }
    }
}

#[async_trait]
impl Tool for AudioSampleTool {
    fn name(&self) -> &str {
        "audio_sample"
    }

    fn description(&self) -> &str {
        "Sample audio from the I2S microphone attached to the ESP32-S3 board. \
         Returns the RMS audio level (0.0–1.0) or raw PCM samples. \
         Use this to detect sound levels or record audio snippets."
    }

    fn parameters_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "duration_ms": {
                    "type": "integer",
                    "description": "Duration to sample in milliseconds (10–1000). Default: 100.",
                    "minimum": AUDIO_DURATION_MIN_MS,
                    "maximum": AUDIO_DURATION_MAX_MS,
                    "default": AUDIO_DURATION_DEFAULT_MS
                },
                "raw": {
                    "type": "boolean",
                    "description": "If true, return raw PCM samples. If false, return RMS level. Default: false.",
                    "default": false
                }
            }
        })
    }

    async fn execute(&self, args: Value) -> anyhow::Result<ToolResult> {
        let duration_ms = args
            .get("duration_ms")
            .and_then(|v| v.as_u64())
            .unwrap_or(AUDIO_DURATION_DEFAULT_MS)
            .clamp(AUDIO_DURATION_MIN_MS, AUDIO_DURATION_MAX_MS);
        let raw = args.get("raw").and_then(|v| v.as_bool()).unwrap_or(false);

        tracing::debug!(
            node_id = %self.node_id,
            duration_ms = duration_ms,
            raw = raw,
            "Sampling audio"
        );

        // Send command via MQTT spine if available, otherwise return stub.
        if let Some(ref spine) = self.spine_client {
            let args = json!({
                "duration_ms": duration_ms,
                "raw": raw,
            });
            let result = spine
                .invoke_tool(&self.node_id, "audio_sample", args)
                .await?;
            Ok(tool_result_from_spine(result))
        } else {
            Ok(ToolResult {
                success: true,
                output: format!(
                    "Audio sample requested from node '{}' (duration={}ms, raw={}). \
                     No spine client configured — running in stub mode.",
                    self.node_id, duration_ms, raw
                ),
                error: None,
            })
        }
    }
}

// ── Sensor Read Tool ──────────────────────────────────────────────────────────

/// Tool: read a value from an I2C/SPI sensor on an ESP32-S3 board.
pub struct SensorReadTool {
    node_id: String,
    spine_client: Option<Arc<SpineClient>>,
}

impl SensorReadTool {
    pub fn new(node_id: impl Into<String>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: None,
        }
    }

    pub fn with_spine(node_id: impl Into<String>, spine_client: Arc<SpineClient>) -> Self {
        Self {
            node_id: node_id.into(),
            spine_client: Some(spine_client),
        }
    }
}

#[async_trait]
impl Tool for SensorReadTool {
    fn name(&self) -> &str {
        "sensor_read"
    }

    fn description(&self) -> &str {
        "Read a value from an I2C or SPI sensor attached to the ESP32-S3 board. \
         Supported sensors include BME280 (temperature, humidity, pressure), \
         BMP388 (pressure, altitude, temperature), MPU6050 (accelerometer, gyroscope), \
         LSM6DS3 (accelerometer, gyroscope), SHT31 (temperature, humidity), \
         AHT20 (temperature, humidity), BMP180 (temperature, pressure), \
         INA260 (voltage, current, power), ADS1115 (ADC channels), \
         MAX31855 (thermocouple temperature), and DS18B20 (1-Wire temperature)."
    }

    fn parameters_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "sensor": {
                    "type": "string",
                    "description": "The sensor to read from (e.g., 'bme280', 'mpu6050', 'sht31', 'bmp180', 'bmp388', 'lsm6ds3', 'aht20', 'ina260', 'ads1115', 'max31855', 'ds18b20').",
                    "enum": ["bme280", "mpu6050", "sht31", "bmp180", "bmp388", "lsm6ds3", "aht20", "ina260", "ads1115", "max31855", "ds18b20"]
                },
                "field": {
                    "type": "string",
                    "description": "The field to read (e.g., 'temperature', 'humidity', 'pressure', 'accel_x', 'accel_y', 'accel_z', 'gyro_x', 'gyro_y', 'gyro_z', 'voltage', 'current', 'power', 'channel_0', 'channel_1', 'channel_2', 'channel_3')."
                }
            },
            "required": ["sensor", "field"]
        })
    }

    async fn execute(&self, args: Value) -> anyhow::Result<ToolResult> {
        let sensor = args
            .get("sensor")
            .and_then(|v| v.as_str())
            .ok_or_else(|| anyhow::anyhow!("Missing 'sensor' parameter"))?
            .to_string();
        let field = args
            .get("field")
            .and_then(|v| v.as_str())
            .ok_or_else(|| anyhow::anyhow!("Missing 'field' parameter"))?
            .to_string();

        tracing::debug!(
            node_id = %self.node_id,
            sensor = %sensor,
            field = %field,
            "Reading sensor"
        );

        // Send command via MQTT spine if available, otherwise return stub.
        if let Some(ref spine) = self.spine_client {
            let args = json!({
                "sensor": sensor,
                "field": field,
            });
            let result = spine
                .invoke_tool(&self.node_id, "sensor_read", args)
                .await?;
            Ok(tool_result_from_spine(result))
        } else {
            Ok(ToolResult {
                success: true,
                output: format!(
                    "Sensor read requested from node '{}' (sensor={}, field={}). \
                     No spine client configured — running in stub mode.",
                    self.node_id, sensor, field
                ),
                error: None,
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn camera_capture_tool_has_correct_name() {
        let tool = CameraCaptureTool::new("test-node");
        assert_eq!(tool.name(), "camera_capture");
    }

    #[tokio::test]
    async fn audio_sample_tool_has_correct_name() {
        let tool = AudioSampleTool::new("test-node");
        assert_eq!(tool.name(), "audio_sample");
    }

    #[tokio::test]
    async fn sensor_read_tool_requires_sensor_and_field() {
        let tool = SensorReadTool::new("test-node");
        let result = tool.execute(serde_json::json!({})).await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn sensor_read_tool_executes_with_valid_args() {
        let tool = SensorReadTool::new("test-node");
        let result = tool
            .execute(serde_json::json!({"sensor": "bme280", "field": "temperature"}))
            .await
            .unwrap();
        assert!(result.success);
        assert!(result.output.contains("bme280"));
    }
}
